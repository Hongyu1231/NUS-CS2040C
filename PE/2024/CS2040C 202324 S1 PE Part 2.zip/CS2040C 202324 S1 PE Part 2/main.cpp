
#include <time.h>
#include <iostream>
using namespace std;

void hastTabletest1();
void hastTabletest2();

int main() {

	// uncomment the following code for your testing


	hastTabletest1();
	//hastTabletest2();



}
