#include <iostream>

using namespace std;

int part1Test();

int main()
{

	part1Test();
	return 0;

}