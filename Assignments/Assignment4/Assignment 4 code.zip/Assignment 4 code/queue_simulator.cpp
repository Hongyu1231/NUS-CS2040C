#include "queue_simulator.h"

vector<Customer> QueueSimulator::simulateQueue(
    const vector<Customer>& customers) {
  // TODO: Implement this function.
  return customers;
}
