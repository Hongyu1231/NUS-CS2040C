#include "graph.h"
#include "shortest_path.h"

Path shortestPath(const Graph& g, int source, int dest) {
  return Path(0, vector<int>());
}